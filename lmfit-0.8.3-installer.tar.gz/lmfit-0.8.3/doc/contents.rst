Contents
=================

.. toctree::
   :maxdepth: 3

   intro
   installation
   support
   faq
   parameters
   fitting
   model
   builtin_models
   confidence
   bounds
   constraints
